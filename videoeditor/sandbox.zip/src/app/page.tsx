"use client";

import { VideoEditor } from "@/components/VideoEditor";

export default function Page() {
  return <VideoEditor data-oid="oczhrc_" />;
}